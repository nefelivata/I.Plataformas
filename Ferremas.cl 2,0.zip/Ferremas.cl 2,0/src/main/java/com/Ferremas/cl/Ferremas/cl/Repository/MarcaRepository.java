package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Marca;

@Repository
public interface MarcaRepository extends JpaRepository<Marca, Long> {
    
    // Buscar por nombre exacto
    Optional<Marca> findByNombre(String nombre);

    // Buscar por nombre que contenga
    List<Marca> findByNombreContaining(String nombre);

    // Obtener todas con productos
    @Query("SELECT m FROM Marca m JOIN FETCH m.productos")
    List<Marca> findAllWithProductos();

    // Obtener por ID con productos
    @Query("SELECT m FROM Marca m JOIN FETCH m.productos WHERE m.id = :id")
    Optional<Marca> findByIdWithProductos(@Param("id") Long id);

    // Contar productos por marca
    @Query("SELECT COUNT(p) FROM Producto p WHERE p.marca.id = :marcaId")
    Long countProductosPorMarca(@Param("marcaId") Long marcaId);
}
