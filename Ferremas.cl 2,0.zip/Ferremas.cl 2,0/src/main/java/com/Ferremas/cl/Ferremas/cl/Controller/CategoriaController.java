package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ferremas.cl.Ferremas.cl.Model.Categoria;
import com.Ferremas.cl.Ferremas.cl.Model.Producto;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.CategoriaServiceImpl;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaServiceImpl categoriaService;

    @GetMapping
    public ResponseEntity<List<Categoria>> listarCategorias() {
        return ResponseEntity.ok(categoriaService.listarTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Categoria> obtenerCategoriaPorId(@PathVariable Long id) {
        return categoriaService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/productos")
    public List<Producto> obtenerProductosPorCategoria(@PathVariable Long id) {
        Optional<Categoria> cat = categoriaService.obtenerPorIdConProductos(id);
        return cat.map(Categoria::getProductos).orElse(List.of());
    }

    @PostMapping
    public ResponseEntity<Categoria> crearCategoria(@RequestBody Categoria categoria) {
        Categoria guardada = categoriaService.guardar(categoria);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Categoria> actualizarCategoria(@PathVariable Long id, @RequestBody Categoria categoria) {
        return categoriaService.obtenerPorId(id).map(catExistente -> {
            categoria.setId(id);
            Categoria actualizada = categoriaService.guardar(categoria);
            return ResponseEntity.ok(actualizada);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCategoria(@PathVariable Long id) {
        if (categoriaService.obtenerPorId(id).isPresent()) {
            categoriaService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        categoriaService.eliminartodo();
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/nombre-exacto/{nombre}")
    public ResponseEntity<Categoria> buscarPorNombreExacto(@PathVariable String nombre) {
        return categoriaService.buscarPorNombreExacto(nombre)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/nombre-parcial")
    public ResponseEntity<List<Categoria>> buscarPorNombreParcial(@RequestParam String nombre) {
        return ResponseEntity.ok(categoriaService.buscarPorNombreParcial(nombre));
    }
}
