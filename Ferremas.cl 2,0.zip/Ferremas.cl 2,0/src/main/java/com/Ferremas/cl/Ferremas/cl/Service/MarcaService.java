package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Marca;

public interface MarcaService {
    List<Marca> listarTodas();

    Optional<Marca> obtenerPorId(Long id);

    Marca guardar(Marca marca);

    void eliminar(Long id);

    Optional<Marca> buscarPorNombreExacto(String nombre);

    List<Marca> buscarPorNombreParcial(String nombre);

    List<Marca> obtenerConProductos();

    Optional<Marca> obtenerPorIdConProductos(Long id);

    Long contarProductosPorMarca(Long id);

    void eliminartodo();
}
