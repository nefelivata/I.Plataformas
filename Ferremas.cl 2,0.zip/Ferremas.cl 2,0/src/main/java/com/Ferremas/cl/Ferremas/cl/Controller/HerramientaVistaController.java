package com.Ferremas.cl.Ferremas.cl.Controller;

import com.Ferremas.cl.Ferremas.cl.Service.Impl.ProductoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HerramientaVistaController {

    @Autowired
    private ProductoServiceImpl productoService;

    @GetMapping("/herramientas")
    public String verHerramientas(Model model) {
        model.addAttribute("productos", productoService.listarTodos());
        return "herramientas";
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        productoService.eliminartodo();
        return ResponseEntity.noContent().build();
    }
}