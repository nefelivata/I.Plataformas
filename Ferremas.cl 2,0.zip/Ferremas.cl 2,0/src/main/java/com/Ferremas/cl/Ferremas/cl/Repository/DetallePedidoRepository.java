package com.Ferremas.cl.Ferremas.cl.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.DetallePedido;

@Repository
public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Long>{
    
}
