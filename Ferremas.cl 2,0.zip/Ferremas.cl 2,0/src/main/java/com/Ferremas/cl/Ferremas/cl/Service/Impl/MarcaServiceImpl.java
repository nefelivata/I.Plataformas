package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Marca;
import com.Ferremas.cl.Ferremas.cl.Repository.MarcaRepository;
import com.Ferremas.cl.Ferremas.cl.Service.MarcaService;

@Service
public class MarcaServiceImpl implements MarcaService {
    @Autowired
    private MarcaRepository marcaRepository;

    @Override
    public List<Marca> listarTodas() {
        return marcaRepository.findAll();
    }

    @Override
    public Optional<Marca> obtenerPorId(Long id) {
        return marcaRepository.findById(id);
    }

    @Override
    public Marca guardar(Marca marca) {
        return marcaRepository.save(marca);
    }

    @Override
    public void eliminar(Long id) {
        marcaRepository.deleteById(id);
    }

    @Override
    public Optional<Marca> buscarPorNombreExacto(String nombre) {
        return marcaRepository.findByNombre(nombre);
    }

    @Override
    public List<Marca> buscarPorNombreParcial(String nombre) {
        return marcaRepository.findByNombreContaining(nombre);
    }

    @Override
    public List<Marca> obtenerConProductos() {
        return marcaRepository.findAllWithProductos();
    }

    @Override
    public Optional<Marca> obtenerPorIdConProductos(Long id) {
        return marcaRepository.findByIdWithProductos(id);
    }

    @Override
    public Long contarProductosPorMarca(Long id) {
        return marcaRepository.countProductosPorMarca(id);
    }

    @Override
    public void eliminartodo() {
        marcaRepository.deleteAll();
    }
}
