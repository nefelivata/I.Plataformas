package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Pedido;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long>{
    List<Pedido> findByEstado(String estado);
    List<Pedido> findBySucursalId(Long sucursalId);
}
