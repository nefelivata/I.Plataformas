package com.Ferremas.cl.Ferremas.cl.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ferremas.cl.Ferremas.cl.External.TipoCambioService;

@RestController
@RequestMapping("/divisa")
public class DivisaController {
    private final TipoCambioService tipoCambioService;

    public DivisaController(TipoCambioService tipoCambioService) {
        this.tipoCambioService = tipoCambioService;
    }

    @GetMapping("/dolar")
    public Double obtenerValorDolar() {
        return tipoCambioService.obtenerValorDolar();
    }

    @GetMapping("/a-dolares")
    public Double convertirADolares(@RequestParam Double monto) {
        return tipoCambioService.convertirADolares(monto);
    }

    @GetMapping("/a-pesos")
    public Double convertirAPesos(@RequestParam Double monto) {
        return tipoCambioService.convertirAPesos(monto);
    }

}
