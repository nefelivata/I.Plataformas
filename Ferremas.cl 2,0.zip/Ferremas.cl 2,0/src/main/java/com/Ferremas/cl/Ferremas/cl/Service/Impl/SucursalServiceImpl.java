package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Sucursal;
import com.Ferremas.cl.Ferremas.cl.Repository.SucursalRepository;
import com.Ferremas.cl.Ferremas.cl.Service.SucursalService;

@Service
public class SucursalServiceImpl implements SucursalService {
    @Autowired
    private SucursalRepository sucursalRepository;

    @Override
    public List<Sucursal> listarTodas() {
        return sucursalRepository.findAll();
    }

    @Override
    public Optional<Sucursal> obtenerPorId(Long id) {
        return sucursalRepository.findById(id);
    }

    @Override
    public Sucursal guardar(Sucursal sucursal) {
        return sucursalRepository.save(sucursal);
    }

    @Override
    public void eliminar(Long id) {
        sucursalRepository.deleteById(id);
    }

    @Override
    public List<Sucursal> buscarPorNombreParcial(String nombre) {
        return sucursalRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Override
    public List<Sucursal> buscarPorNombreCiudad(String ciudad) {
        return sucursalRepository.findByCiudad(ciudad);
    }

    @Override
    public void eliminartodo() {
        sucursalRepository.deleteAll();
    }
}
