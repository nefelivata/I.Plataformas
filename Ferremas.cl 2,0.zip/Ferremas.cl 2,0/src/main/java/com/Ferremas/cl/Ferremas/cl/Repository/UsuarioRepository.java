package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long>{
    Optional<Usuario> findByCorreo(String correo);
    Optional<Usuario> findByNombre(String nombre);
    List<Usuario> findByNombreContainingIgnoreCase(String nombre);
    Optional<Usuario> findByNombreAndCorreo(String nombre, String correo);
    List<Usuario> findByRol_Id(Long rolId);
    List<Usuario> findByRolNombre(String nombre);
}
