package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Usuario;
import com.Ferremas.cl.Ferremas.cl.Repository.UsuarioRepository;
import com.Ferremas.cl.Ferremas.cl.Service.UsuarioService;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    @Override
    public Optional<Usuario> obtenerPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    @Override
    public Optional<Usuario> buscarPorCorreo(String correo) {
        return usuarioRepository.findByCorreo(correo);
    }

    @Override
    public Optional<Usuario> buscarPorNombre(String nombre) {
        return usuarioRepository.findByNombre(nombre);
    }

    @Override
    public List<Usuario> buscarPorNombreParcial(String nombre) {
        return usuarioRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Override
    public Optional<Usuario> buscarPorNombreYCorreo(String nombre, String correo) {
        return usuarioRepository.findByNombreAndCorreo(nombre, correo);
    }

    @Override
    public List<Usuario> buscarPorRolId(Long rolId) {
        return usuarioRepository.findByRol_Id(rolId);
    }

    @Override
    public List<Usuario> buscarPorRolNombre(String nombre) {
        return usuarioRepository.findByRolNombre(nombre);
    }

    @Override
    public Usuario guardar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    @Override
    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }

    @Override
    public void eliminartodo() {
        usuarioRepository.deleteAll();
    }
}
