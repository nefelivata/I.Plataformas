package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Inventario;

public interface InventarioService {
    List<Inventario> listarTodos();

    Optional<Inventario> obtenerPorId(Long id);

    Inventario guardar(Inventario inventario);

    void eliminar(Long id);

    List<Inventario> buscarPorProductoId(Long productoId);

    List<Inventario> buscarPorSucursalId(Long sucursalId);

    List<Inventario> buscarPorSucursalConRelaciones(Long sucursalId);

    List<Inventario> buscarStockBajo(int cantidad);

    Integer obtenerStockTotal(Long productoId);

    void eliminartodo();
}
