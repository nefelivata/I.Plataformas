package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Inventario;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long>{
      // Buscar por producto
    List<Inventario> findByProductoId(Long productoId);

    // Buscar por sucursal
    List<Inventario> findBySucursalId(Long sucursalId);

    // Buscar inventario por sucursal con relaciones
    @Query("SELECT i FROM Inventario i JOIN FETCH i.producto WHERE i.sucursal.id = :sucursalId")
    List<Inventario> findBySucursalIdWithRelations(@Param("sucursalId") Long sucursalId);

    // Buscar inventario con stock bajo
    @Query("SELECT i FROM Inventario i WHERE i.cantidad < :cantidadMinima")
    List<Inventario> findByStockBajo(@Param("cantidadMinima") int cantidadMinima);

    // Obtener stock total por producto
    @Query("SELECT SUM(i.cantidad) FROM Inventario i WHERE i.producto.id = :productoId")
    Integer getStockTotalPorProducto(@Param("productoId") Long productoId);
}
