package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Sucursal;

@Repository
public interface SucursalRepository extends JpaRepository<Sucursal, Long>{
    List<Sucursal> findByCiudad(String ciudad);
    List<Sucursal> findByNombreContainingIgnoreCase(String nombre);
}
