package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Sucursal;

public interface SucursalService {
    List<Sucursal> listarTodas();

    Optional<Sucursal> obtenerPorId(Long id);

    Sucursal guardar(Sucursal sucursal);

    void eliminar(Long id);

    List<Sucursal> buscarPorNombreParcial(String nombre);

    List<Sucursal> buscarPorNombreCiudad(String nombre);

    void eliminartodo();
}
