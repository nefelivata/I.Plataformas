package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ferremas.cl.Ferremas.cl.Model.Inventario;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.InventarioServiceImpl;

@RestController
@RequestMapping("/inventarios")
public class InventarioController {

    @Autowired
    private InventarioServiceImpl inventarioService;

    @GetMapping
    public ResponseEntity<List<Inventario>> listarInventarios() {
        return ResponseEntity.ok(inventarioService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inventario> obtenerInventarioPorId(@PathVariable Long id) {
        return inventarioService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Inventario> crearInventario(@RequestBody Inventario inventario) {
        Inventario guardado = inventarioService.guardar(inventario);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Inventario> actualizarInventario(@PathVariable Long id, @RequestBody Inventario inventario) {
        return inventarioService.obtenerPorId(id).map(invExistente -> {
            inventario.setId(id);
            Inventario actualizado = inventarioService.guardar(inventario);
            return ResponseEntity.ok(actualizado);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInventario(@PathVariable Long id) {
        if (inventarioService.obtenerPorId(id).isPresent()) {
            inventarioService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/producto/{productoId}")
    public ResponseEntity<List<Inventario>> buscarPorProductoId(@PathVariable Long productoId) {
        return ResponseEntity.ok(inventarioService.buscarPorProductoId(productoId));
    }

    @GetMapping("/sucursal/{sucursalId}")
    public ResponseEntity<List<Inventario>> buscarPorSucursalId(@PathVariable Long sucursalId) {
        return ResponseEntity.ok(inventarioService.buscarPorSucursalId(sucursalId));
    }

    @GetMapping("/sucursal/con-relaciones/{sucursalId}")
    public ResponseEntity<List<Inventario>> buscarPorSucursalIdConRelaciones(@PathVariable Long sucursalId) {
        return ResponseEntity.ok(inventarioService.buscarPorSucursalConRelaciones(sucursalId));
    }

    @GetMapping("/stock-bajo")
    public ResponseEntity<List<Inventario>> buscarStockBajo(@RequestParam int cantidad) {
        return ResponseEntity.ok(inventarioService.buscarStockBajo(cantidad));
    }

    @GetMapping("/stock-total/producto/{productoId}")
    public ResponseEntity<Integer> obtenerStockTotalPorProducto(@PathVariable Long productoId) {
        return ResponseEntity.ok(inventarioService.obtenerStockTotal(productoId));
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        inventarioService.eliminartodo();
        return ResponseEntity.noContent().build();
    }
}