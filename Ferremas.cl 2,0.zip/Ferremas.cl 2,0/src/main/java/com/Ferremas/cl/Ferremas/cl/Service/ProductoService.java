package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Producto;

public interface ProductoService {
    List<Producto> listarTodos();

    Optional<Producto> obtenerPorId(Long id);

    Producto guardar(Producto producto);

    void eliminar(Long id);

    List<Producto> buscarPorNombreParcial(String nombre);

    List<Producto> buscarPorCategoria(Long categoriaId);

    List<Producto> buscarPorMarca(Long marcaId);

    void eliminartodo();
}
