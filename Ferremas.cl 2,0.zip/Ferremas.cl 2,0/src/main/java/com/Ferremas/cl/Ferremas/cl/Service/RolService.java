package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Rol;

public interface RolService {
    List<Rol> obtenerTodos();

    Optional<Rol> obtenerPorId(Long id);

    Optional<Rol> buscarPorNombre(String nombre);

    Rol guardar(Rol rol);

    void eliminar(Long id);

    void eliminartodo();
}
