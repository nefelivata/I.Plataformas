package com.Ferremas.cl.Ferremas.cl.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import com.Ferremas.cl.Ferremas.cl.Model.Producto;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.ProductoServiceImpl;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.MediaType;
import java.util.*;

@Controller
public class CarritoController {

    @Autowired
    private ProductoServiceImpl productoService;

    @GetMapping("/carrito")
    public String verCarrito(Model model, HttpSession session) {
        List<Map<String, Object>> carrito = (List<Map<String, Object>>) session.getAttribute("carrito");
        if (carrito == null)
            carrito = new ArrayList<>();
        double total = carrito.stream()
                .mapToDouble(item -> (double) item.get("subtotal"))
                .sum();
        model.addAttribute("detalle", carrito);
        model.addAttribute("total", total);
        return "carrito";
    }

    @PostMapping("/carrito")
    public String agregarAlCarrito(@RequestParam int productoId, @RequestParam int cantidad, HttpSession session) {
        Optional<Producto> productoOpt = productoService.obtenerPorId((long) productoId);
        if (productoOpt.isEmpty()) {
            return "redirect:/carrito";
        }
        Producto producto = productoOpt.get();
        List<Map<String, Object>> carrito = (List<Map<String, Object>>) session.getAttribute("carrito");
        if (carrito == null)
            carrito = new ArrayList<>();
        Map<String, Object> item = new HashMap<>();
        item.put("productoId", producto.getId());
        item.put("nombre", producto.getNombre());
        item.put("cantidad", cantidad);
        item.put("precio", producto.getPrecio());
        item.put("subtotal", producto.getPrecio() * cantidad);
        carrito.add(item);
        session.setAttribute("carrito", carrito);
        return "redirect:/carrito";
    }

    @PostMapping("/carrito/eliminar")
    public String eliminarDelCarrito(@RequestParam int productoId, HttpSession session) {
        List<Map<String, Object>> carrito = (List<Map<String, Object>>) session.getAttribute("carrito");
        if (carrito != null) {
            carrito.removeIf(item -> ((Long) item.get("productoId")).intValue() == productoId);
            if (carrito.isEmpty()) {
                session.removeAttribute("carrito");
            } else {
                session.setAttribute("carrito", carrito);
            }
        }
        return "redirect:/carrito";
    }

    @ModelAttribute("totalCarrito")
    public Integer getTotalCarrito(HttpSession session) {
        List<Map<String, Object>> carrito = (List<Map<String, Object>>) session.getAttribute("carrito");
        if (carrito == null) {
            return 0;
        }
        return (int) Math.round(
                carrito.stream()
                        .mapToDouble(item -> (Double) item.get("subtotal"))
                        .sum());
    }

    @PostMapping("/comprar")
    public String comprar(@RequestParam double monto, HttpSession session) {
        session.removeAttribute("carrito");
        return "redirect:/iniciar";
    }

    @PostMapping("/pagar")
    public String procesarPago(HttpSession session) {
        Integer montoTotal = getTotalCarrito(session);
        Map<String, Object> body = new HashMap<>();
        body.put("monto", montoTotal);

        WebClient webClient = WebClient.create("http://localhost:8080");

        try {
            Map<String, Object> respuestaPago = webClient.post()
                    .uri("/pago/iniciar")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            String urlWebpay = (String) respuestaPago.get("full_url");
            if (urlWebpay != null && !urlWebpay.isEmpty()) {
                return "redirect:" + urlWebpay;
            } else {
                return "redirect:/pago-fallido";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/pago-fallido";
        }
    }
}