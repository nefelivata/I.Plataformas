package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.DetallePedido;

public interface DetallePedidoService {
    List<DetallePedido> listarTodos();

    Optional<DetallePedido> obtenerPorId(Long id);

    DetallePedido guardar(DetallePedido detalle);

    void eliminar(Long id);

    void eliminartodo();
}
