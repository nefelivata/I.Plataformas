package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import com.Ferremas.cl.Ferremas.cl.Model.Marca;

import com.Ferremas.cl.Ferremas.cl.Service.Impl.MarcaServiceImpl;

@RestController
@RequestMapping("/marcas")
public class MarcaController {

    @Autowired
    private MarcaServiceImpl marcaService;

    @GetMapping
    public ResponseEntity<List<Marca>> listarMarcas() {
        return ResponseEntity.ok(marcaService.listarTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Marca> obtenerMarcaPorId(@PathVariable Long id) {
        return marcaService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Marca> crearMarca(@RequestBody Marca marca) {
        Marca guardada = marcaService.guardar(marca);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Marca> actualizarMarca(@PathVariable Long id, @RequestBody Marca marca) {
        return marcaService.obtenerPorId(id).map(marExistente -> {
            marca.setId(id);
            Marca actualizada = marcaService.guardar(marca);
            return ResponseEntity.ok(actualizada);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarMarca(@PathVariable Long id) {
        if (marcaService.obtenerPorId(id).isPresent()) {
            marcaService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/nombre-exacto/{nombre}")
    public ResponseEntity<Marca> buscarPorNombreExacto(@PathVariable String nombre) {
        return marcaService.buscarPorNombreExacto(nombre)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/nombre-parcial")
    public ResponseEntity<List<Marca>> buscarPorNombreParcial(@RequestParam String nombre) {
        return ResponseEntity.ok(marcaService.buscarPorNombreParcial(nombre));
    }

    @GetMapping("/con-productos")
    public ResponseEntity<List<Marca>> obtenerMarcasConProductos() {
        return ResponseEntity.ok(marcaService.obtenerConProductos());
    }

    @GetMapping("/{id}/con-productos")
    public ResponseEntity<Marca> obtenerMarcaPorIdConProductos(@PathVariable Long id) {
        return marcaService.obtenerPorIdConProductos(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/conteo-productos")
    public ResponseEntity<Long> contarProductosPorMarca(@PathVariable Long id) {
        return ResponseEntity.ok(marcaService.contarProductosPorMarca(id));
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        marcaService.eliminartodo();
        return ResponseEntity.noContent().build();
    }
}
