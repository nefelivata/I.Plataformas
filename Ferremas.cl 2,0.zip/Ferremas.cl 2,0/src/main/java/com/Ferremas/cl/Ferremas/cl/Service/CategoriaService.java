package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Categoria;

public interface CategoriaService {
    List<Categoria> listarTodas();

    Optional<Categoria> obtenerPorId(Long id);

    Categoria guardar(Categoria categoria);

    void eliminar(Long id);

    Optional<Categoria> buscarPorNombreExacto(String nombre);

    List<Categoria> buscarPorNombreParcial(String nombre);

    List<Categoria> obtenerConProductos();

    Optional<Categoria> obtenerPorIdConProductos(Long id);

    void eliminartodo();
}
