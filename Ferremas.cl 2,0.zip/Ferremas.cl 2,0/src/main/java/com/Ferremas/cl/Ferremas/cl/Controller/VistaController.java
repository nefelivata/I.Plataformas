package com.Ferremas.cl.Ferremas.cl.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import io.swagger.v3.oas.annotations.Operation;
import com.Ferremas.cl.Ferremas.cl.Model.Producto;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.ProductoServiceImpl;
import java.util.List;

@Controller
public class VistaController {
    @Autowired
    ProductoServiceImpl productoService;

    @GetMapping("/index")
    public String mostrarIndex(Model model) {
        List<Producto> productos = productoService.listarTodos();
        model.addAttribute("productos", productos);
        return "index";
    }

    @GetMapping("/pinturas")
    public String mostrarPinturas() {
        return "pinturas";
    }

    @GetMapping("/electricidad")
    public String mostrarElectricidad() {
        return "electricidad";
    }

    @GetMapping("/seguridad")
    public String mostrarSeguridad() {
        return "seguridad";
    }

    @GetMapping("/nosotros")
    public String mostrarNosotros() {
        return "nosotros";
    }

    

}