package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Pedido;

public interface PedidoService {
    List<Pedido> listarTodos();

    Optional<Pedido> obtenerPorId(Long id);

    Pedido guardar(Pedido pedido);

    void eliminar(Long id);

    List<Pedido> buscarPorEstado(String estado);

    List<Pedido> buscarPorSucursalId(Long sucursalId);

    void eliminartodo();
}
