package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Ferremas.cl.Ferremas.cl.Model.DetallePedido;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.DetallePedidoServiceImpl;

@RestController
@RequestMapping("detalles-pedido")
public class DetallePedidoController {
    @Autowired
    private DetallePedidoServiceImpl detallePedidoService;

    @GetMapping
    public ResponseEntity<List<DetallePedido>> listarDetallesPedido() {
        return ResponseEntity.ok(detallePedidoService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DetallePedido> obtenerDetallePedidoPorId(@PathVariable Long id) {
        return detallePedidoService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<DetallePedido> crearDetallePedido(@RequestBody DetallePedido detallePedido) {
        DetallePedido guardado = detallePedidoService.guardar(detallePedido);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DetallePedido> actualizarDetallePedido(@PathVariable Long id,
            @RequestBody DetallePedido detallePedido) {
        return detallePedidoService.obtenerPorId(id).map(detExistente -> {
            detallePedido.setId(id);
            DetallePedido actualizado = detallePedidoService.guardar(detallePedido);
            return ResponseEntity.ok(actualizado);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDetallePedido(@PathVariable Long id) {
        if (detallePedidoService.obtenerPorId(id).isPresent()) {
            detallePedidoService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        detallePedidoService.eliminartodo();
        return ResponseEntity.noContent().build();
    }
}
