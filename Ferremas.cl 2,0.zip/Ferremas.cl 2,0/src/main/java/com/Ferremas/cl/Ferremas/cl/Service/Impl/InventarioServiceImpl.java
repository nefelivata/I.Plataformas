package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Inventario;
import com.Ferremas.cl.Ferremas.cl.Repository.InventarioRepository;
import com.Ferremas.cl.Ferremas.cl.Service.InventarioService;

@Service
public class InventarioServiceImpl implements InventarioService {
    @Autowired
    private InventarioRepository inventarioRepository;

    @Override
    public List<Inventario> listarTodos() {
        return inventarioRepository.findAll();
    }

    @Override
    public Optional<Inventario> obtenerPorId(Long id) {
        return inventarioRepository.findById(id);
    }

    @Override
    public Inventario guardar(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }

    @Override
    public void eliminar(Long id) {
        inventarioRepository.deleteById(id);
    }

    @Override
    public List<Inventario> buscarPorProductoId(Long productoId) {
        return inventarioRepository.findByProductoId(productoId);
    }

    @Override
    public List<Inventario> buscarPorSucursalId(Long sucursalId) {
        return inventarioRepository.findBySucursalId(sucursalId);
    }

    @Override
    public List<Inventario> buscarPorSucursalConRelaciones(Long sucursalId) {
        return inventarioRepository.findBySucursalIdWithRelations(sucursalId);
    }

    @Override
    public List<Inventario> buscarStockBajo(int cantidad) {
        return inventarioRepository.findByStockBajo(cantidad);
    }

    @Override
    public Integer obtenerStockTotal(Long productoId) {
        return inventarioRepository.getStockTotalPorProducto(productoId);
    }

    @Override
    public void eliminartodo() {
        inventarioRepository.deleteAll();
    }
}
