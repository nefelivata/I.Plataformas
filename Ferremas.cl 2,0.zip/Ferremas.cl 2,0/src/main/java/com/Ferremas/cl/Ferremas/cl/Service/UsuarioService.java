package com.Ferremas.cl.Ferremas.cl.Service;

import java.util.List;
import java.util.Optional;

import com.Ferremas.cl.Ferremas.cl.Model.Usuario;

public interface UsuarioService {
    List<Usuario> obtenerTodos();

    Optional<Usuario> obtenerPorId(Long id);

    Optional<Usuario> buscarPorCorreo(String correo);

    Optional<Usuario> buscarPorNombre(String nombre);

    List<Usuario> buscarPorNombreParcial(String nombre);

    Optional<Usuario> buscarPorNombreYCorreo(String nombre, String correo);

    List<Usuario> buscarPorRolId(Long rolId);

    List<Usuario> buscarPorRolNombre(String nombre);

    Usuario guardar(Usuario usuario);

    void eliminar(Long id);

    void eliminartodo();
}
