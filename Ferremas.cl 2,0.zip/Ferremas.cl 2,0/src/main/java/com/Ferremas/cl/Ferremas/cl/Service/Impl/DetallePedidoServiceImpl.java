package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.DetallePedido;
import com.Ferremas.cl.Ferremas.cl.Repository.DetallePedidoRepository;
import com.Ferremas.cl.Ferremas.cl.Service.DetallePedidoService;

@Service
public class DetallePedidoServiceImpl implements DetallePedidoService {
    @Autowired
    private DetallePedidoRepository detallePedidoRepository;

    @Override
    public List<DetallePedido> listarTodos() {
        return detallePedidoRepository.findAll();
    }

    @Override
    public Optional<DetallePedido> obtenerPorId(Long id) {
        return detallePedidoRepository.findById(id);
    }

    @Override
    public DetallePedido guardar(DetallePedido detalle) {
        return detallePedidoRepository.save(detalle);
    }

    @Override
    public void eliminar(Long id) {
        detallePedidoRepository.deleteById(id);
    }

    @Override
    public void eliminartodo() {
        detallePedidoRepository.deleteAll();
    }

}
