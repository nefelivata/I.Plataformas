package com.Ferremas.cl.Ferremas.cl.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Ferremas.cl.Ferremas.cl.Model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{
    Optional<Producto> findByNombre(String nombre);
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
    List<Producto> findByCategoriaId(Long categoriaId);
    List<Producto> findByMarcaId(Long marcaId);
}
