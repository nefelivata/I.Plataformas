package com.Ferremas.cl.Ferremas.cl.Dto;

public class PagoResultDto {
    public String vci;
    public Integer amount;
    public String status;
    public String buyOrder;
    public String sessionId;
    public String cardNumber;
    public String accountingDate;
    public String transactionDate;
    public String authorizationCode;
    public String paymentTypeCode;
    public Integer responseCode;
    public Integer installmentsAmount;
    public Integer installmentsNumber;
    public Integer balance;
}
