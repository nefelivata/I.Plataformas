package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Categoria;
import com.Ferremas.cl.Ferremas.cl.Repository.CategoriaRepository;
import com.Ferremas.cl.Ferremas.cl.Service.CategoriaService;

@Service
public class CategoriaServiceImpl implements CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public List<Categoria> listarTodas() {
        return categoriaRepository.findAll();
    }

    @Override
    public Optional<Categoria> obtenerPorId(Long id) {
        return categoriaRepository.findById(id);
    }

    @Override
    public Categoria guardar(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    @Override
    public void eliminar(Long id) {
        categoriaRepository.deleteById(id);
    }

    @Override
    public Optional<Categoria> buscarPorNombreExacto(String nombre) {
        return categoriaRepository.findByNombre(nombre);
    }

    @Override
    public List<Categoria> buscarPorNombreParcial(String nombre) {
        return categoriaRepository.findByNombreContaining(nombre);
    }

    @Override
    public List<Categoria> obtenerConProductos() {
        return categoriaRepository.findAllWithProductos();
    }

    @Override
    public Optional<Categoria> obtenerPorIdConProductos(Long id) {
        return categoriaRepository.findByIdWithProductos(id);
    }

    @Override
    public void eliminartodo() {
        categoriaRepository.deleteAll();
    }
}
