package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.reactive.function.client.WebClient;
import io.swagger.v3.oas.annotations.Operation;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.PagoServiceImpl;

import reactor.core.publisher.Mono;

@Controller
@RequestMapping("/pago")
public class PagoController {

    private final PagoServiceImpl pagoService;
    private Map<String, Object> ultimoResultadoPago;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public PagoController(PagoServiceImpl pagoService) {
        this.pagoService = pagoService;
    }

    @PostMapping("/iniciar")
    public Mono<ResponseEntity<Map<String, Object>>> iniciarPago(@RequestBody Map<String, Object> body) {
        Integer monto = Integer.valueOf(body.get("monto").toString());
        return pagoService.iniciarTransaccion(monto)
                .map(ResponseEntity::ok);
    }

    @GetMapping("/confirmar")
    public Mono<String> confirmarPagoGet(@RequestParam("token_ws") String token) {
        return pagoService.confirmarTransaccion(token)
                .map(response -> {
                    ultimoResultadoPago = response;
                    return "redirect:/pago/getresult?token=" + token;
                });
    }

    @PostMapping("/confirmar")
    public Mono<String> confirmarPagoPost(@RequestParam("token_ws") String token) {
        return pagoService.confirmarTransaccion(token)
                .map(response -> {
                    ultimoResultadoPago = response;
                    return "redirect:/pago/getresult?token=" + token;
                });
    }

    @GetMapping("/getresult")
    public ResponseEntity<?> getResult(@RequestParam("token") String token) {
        String commerceCode = pagoService.getCommerceCode();
        String apiKey = pagoService.getApiKey();

        WebClient webClient = webClientBuilder.baseUrl("https://webpay3gint.transbank.cl").build();

        Map<String, Object> response = webClient.put()
                .uri("/rswebpaytransaction/api/webpay/v1.0/transactions/{token}", token)
                .header("Tbk-Api-Key-Id", commerceCode)
                .header("Tbk-Api-Key-Secret", apiKey)
                .retrieve()
                .bodyToMono(Map.class)
                .block();

        return ResponseEntity.ok(response);
    }

}