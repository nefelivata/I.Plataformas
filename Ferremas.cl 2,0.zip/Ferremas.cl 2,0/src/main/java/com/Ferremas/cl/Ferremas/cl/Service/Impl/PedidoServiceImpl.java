package com.Ferremas.cl.Ferremas.cl.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ferremas.cl.Ferremas.cl.Model.Pedido;
import com.Ferremas.cl.Ferremas.cl.Repository.PedidoRepository;
import com.Ferremas.cl.Ferremas.cl.Service.PedidoService;

@Service
public class PedidoServiceImpl implements PedidoService {
    @Autowired
    private PedidoRepository pedidoRepository;

    @Override
    public List<Pedido> listarTodos() {
        return pedidoRepository.findAll();
    }

    @Override
    public Optional<Pedido> obtenerPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    @Override
    public Pedido guardar(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    @Override
    public void eliminar(Long id) {
        pedidoRepository.deleteById(id);
    }

    @Override
    public List<Pedido> buscarPorEstado(String estado) {
        return pedidoRepository.findByEstado(estado);
    }

    @Override
    public List<Pedido> buscarPorSucursalId(Long sucursalId) {
        return pedidoRepository.findBySucursalId(sucursalId);
    }

    @Override
    public void eliminartodo() {
        pedidoRepository.deleteAll();
    }
}
