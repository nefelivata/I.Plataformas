package com.Ferremas.cl.Ferremas.cl.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import com.Ferremas.cl.Ferremas.cl.Model.Producto;
import com.Ferremas.cl.Ferremas.cl.Model.Usuario;
import com.Ferremas.cl.Ferremas.cl.Service.Impl.UsuarioServiceImpl;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioServiceImpl usuarioService;

    @GetMapping
    public List<Usuario> obtenerTodos() {
        return usuarioService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<Usuario> obtenerPorId(@PathVariable Long id) {
        return usuarioService.obtenerPorId(id);
    }

    @GetMapping("/buscar-correo")
    public Optional<Usuario> buscarPorCorreo(@RequestParam String correo) {
        return usuarioService.buscarPorCorreo(correo);
    }

    @GetMapping("/buscar-nombre")
    public Optional<Usuario> buscarPorNombre(@RequestParam String nombre) {
        return usuarioService.buscarPorNombre(nombre);
    }

    @GetMapping("/buscar-nombre-parcial")
    public List<Usuario> buscarPorNombreParcial(@RequestParam String nombre) {
        return usuarioService.buscarPorNombreParcial(nombre);
    }

    @GetMapping("/buscar-nombre-correo")
    public Optional<Usuario> buscarPorNombreYCorreo(
            @RequestParam String nombre,
            @RequestParam String correo) {
        return usuarioService.buscarPorNombreYCorreo(nombre, correo);
    }

    @GetMapping("/buscar-rol-id")
    public List<Usuario> buscarPorRolId(@RequestParam Long rolId) {
        return usuarioService.buscarPorRolId(rolId);
    }

    @GetMapping("/buscar-rol-nombre")
    public List<Usuario> buscarPorRolNombre(@RequestParam String nombre) {
        return usuarioService.buscarPorRolNombre(nombre);
    }

    @PostMapping
    public Usuario guardar(@RequestBody Usuario usuario) {
        return usuarioService.guardar(usuario);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return usuarioService.obtenerPorId(id).map(usuarioExistente -> {
            usuario.setId(id);
            Usuario actualizado = usuarioService.guardar(usuario);
            return ResponseEntity.ok(actualizado);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        usuarioService.eliminar(id);
    }

    @DeleteMapping
    public ResponseEntity<Void> eliminarTodo() {
        usuarioService.eliminartodo();
        return ResponseEntity.noContent().build();
    }
}
